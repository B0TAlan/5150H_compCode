#ifndef AUTONS_H
#define AUTONS_H

extern void Skills();

extern void right20();
extern void rightMid();

extern void left20();
extern void leftMid();

extern void Awp();

extern void NoTon();

#endif