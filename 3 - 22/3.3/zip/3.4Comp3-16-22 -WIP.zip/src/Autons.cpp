#include "vex.h"
#include "Classes.h"
LiftShortcut lift;
ClampShortcuts clamp;
BackLiftShortcuts bl;
PringleShortcuts pring;

