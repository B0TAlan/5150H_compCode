#ifndef AUTONS_H
#define AUTONS_H

extern void Skills();

extern void rightA();
extern void rightMid();
extern void right20();

extern void left20();
extern void leftMid();

extern void Awp();

extern void NoTon();

#endif