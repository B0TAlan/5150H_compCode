/* Clamp1.setVelocity(200, percent);
    bL.spinFor(-1.75, rev);
    driveBase.driveFor(-8, inches);
    bL.setVelocity(200, percent);
    //driveBase.driveFor(7, inches);
    bLoUp();
    bLrabDown();
    driveBase.turnFor(-92, rotationUnits::deg);
    driveBase.driveFor(-5, inches);
    driveBase.turnFor(-80, rotationUnits::deg, 50, velocityUnits::pct);
    driveBase.setDriveVelocity(200, percent);//set the speed of robot (speed up robot)
    driveBase.driveFor(forward, 38, inches);// drive 43 inches forward to closed distance between robot and mGoal
    driveBase.setDriveVelocity(15, percent);// slow down 
    driveBase.driveFor(forward, 7, inches);// drive 10 inches forward (i inch form mGaol)
 
    //driveBase.driveFor(8, inches);
    */