#ifndef AUTONS_H
#define AUTONS_H

extern bool mLoads;
extern bool prinLine;
extern bool AutoDone;

extern void testing();
extern void right20();
extern void right40();
extern void left20();
#endif