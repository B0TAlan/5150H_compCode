
#include "vex.h"

bool pring = false;

void left20();

void right20(){
  if(!pring){
    Brain.Screen.print("snorting a line of pringles");
  }else if(pring){
    Brain.Screen.print("FEED ME");
  }else {
    Brain.Screen.print("fuck my life is pain :(");
  }
}

void right40(){
  if(!pring){
    Brain.Screen.print("snorting a line of pringles");
  }else if(pring){
    Brain.Screen.print("FEED ME");
  }else {
    Brain.Screen.print("fuck my life is pain :(");
  }
}

void rightMid();