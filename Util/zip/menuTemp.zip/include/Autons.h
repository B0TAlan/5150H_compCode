
extern bool pring;
extern void left20();
extern void right20();
extern void right40();
extern void rightMid();

