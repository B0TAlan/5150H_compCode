//------- Gloabal Vars -------//
 extern bool sM;
 extern bool auton;
 extern bool clampOn;
 extern bool bLD;
 extern int Pring;
 extern bool waitTING;
 extern bool RobotIsWorking;
 
//----------------------------//


//------- Voids -------//
 extern void lUp(void);
 extern void lDown(void);
 extern void clamp1On(void);
 extern void clamp1Off(void);
 extern void Aclamp1On(void);
 extern void bLReset(void);
 extern void bLUp(void);
 extern void bLDown(void);
 extern void displayTemp(void);
 extern void tempcheck(void);
 extern void pringON(void);
 extern void tankCont(void);
//----------------------//