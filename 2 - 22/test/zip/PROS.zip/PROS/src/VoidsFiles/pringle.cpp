#include"main.h"

//HELPER
void setPing(int power){
  pringle = power;


}

//Driver control
void setPringMotor(){
  int  pringPower= 0;


}
