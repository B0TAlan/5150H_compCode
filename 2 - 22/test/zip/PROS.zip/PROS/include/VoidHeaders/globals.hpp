#include "main.h"

//Motors
extern pros::Motor lift;
extern pros::Motor clamp;
extern pros::Motor bL;
extern pros::Motor pringle;
extern pros::Motor lf;
extern pros::Motor lb;
extern pros::Motor rf;
extern pros::Motor rb;

//Controller
extern pros::Controller controller;
