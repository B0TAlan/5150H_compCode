#include"main.h"

//HELPER
void setClamp(int power);

//Driver control
void setClampOn();
void setClampOff();
void clampControl();
