#include"main.h"

//HELPER
void setLift(int power);


//Driver control
void setLiftMotor();
