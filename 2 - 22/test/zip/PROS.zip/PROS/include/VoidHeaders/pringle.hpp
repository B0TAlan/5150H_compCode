#include"main.h"

//HELPER
void setPing(int power);

//Driver control
void setPringMotor();
