#include"main.h"

//helper
void setDrive(int left, int right);


//teleOP
void setDriveMotors();
