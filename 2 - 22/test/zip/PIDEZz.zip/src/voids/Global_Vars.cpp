//------------------------------------------------ Gloabal Vars ------------------------------------------------------//
 bool sM = true;    // used to make the scoring macro repeat DNU
 bool auton = true; // was used to trigger line sensor in auton DNU for solo awp
 bool clampOn =
     false; // used to have the robot to wait for the clamp close in auton
 bool RobotIsWorking = false; // to always make sure the robot is working
 int Pring = 2;               // used to turn off and on the pringle intake
 bool bLD = false; // used to state the whether the backLift is down(true) or
                   // up(false)| backLift up at start
 bool waitTING = true;// used to control the wait till completion bool DNU
 
 //--------------------------------------------------------------------------------------------------------------------//