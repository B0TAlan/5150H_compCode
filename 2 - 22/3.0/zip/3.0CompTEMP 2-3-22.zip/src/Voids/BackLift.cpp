#include "vex.h"
#include <iostream>
#include "stdarg.h"
#include <cstring>
#include <string.h>

void bLDown() {
  bL.set(true);
}

void bLUp() {
  bL.set(false);
}