#include"../Classes/DriveMotors.cpp"
#include"../Classes/PneumaticClass.cpp"

extern MotorControl DriveMotors;

extern PneumaticsControl Pistions;