#include"../Functions/BrakeToggle.cpp"

extern int brakeMode;

extern brakeType driveBrake;

extern void setDriveMode();