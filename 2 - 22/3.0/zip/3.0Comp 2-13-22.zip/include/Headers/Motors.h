#include "../Functions/Motors.cpp"
// Lift functions
extern void setLiftVel(int p);
extern void liftControl();

// Pringle intake functions(p2)
void pringleIntake();

// Pringle intake functions(p1)
void setPingle();
void spinPringle();