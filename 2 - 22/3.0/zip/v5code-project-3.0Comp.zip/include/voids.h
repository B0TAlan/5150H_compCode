extern void clampOn();
extern void tankCont();