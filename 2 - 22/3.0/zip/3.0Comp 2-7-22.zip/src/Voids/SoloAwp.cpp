#include "vex.h"
#include <iostream>
#include "stdarg.h"
#include <cstring>
#include <string.h>

void soloWP(){
  //Brain.Screen.print("INSET CODE HERE");
  Brain.Screen.drawImageFromFile("test2.bmp", 100, 100);
}