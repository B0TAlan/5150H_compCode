#include "vex.h"
#include <iostream>
#include "stdarg.h"
#include <cstring>
#include <string.h>