#include "../Functions/Motors.cpp"

extern void setLiftVel(int p);

extern void liftControl();