
extern void logTank();
