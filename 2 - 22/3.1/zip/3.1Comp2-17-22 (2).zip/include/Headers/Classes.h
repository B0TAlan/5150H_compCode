//#include"../Classes/DriveMotors.cpp"
#include"../Classes/PneumaticClass.cpp"
#include"../Classes/AutonShortcuts.cpp"
#include"../Classes/PID.cpp"

int defualtDrive();
int defualtTurn();



extern PneumaticsControl Pistions;

extern LiftShortcuts aL;

extern PidController PID;