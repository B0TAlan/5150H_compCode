#include "../Autons/Left.cpp"
#include "../Autons/Right.cpp"
#include "../Autons/Other.cpp"

extern void leftMid();