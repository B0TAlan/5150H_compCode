
extern int brakeMode;

extern vex::brakeType driveBrake;

extern void setDriveMode();

extern void logTank();
