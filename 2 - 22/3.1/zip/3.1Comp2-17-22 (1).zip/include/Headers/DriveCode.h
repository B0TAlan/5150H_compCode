#ifndef DRIVECODE_H
#define DRIVECODE_H

extern int brakeMode;

extern vex::brakeType driveBrake;

extern void setDriveMode();

extern void logTank();

#endif