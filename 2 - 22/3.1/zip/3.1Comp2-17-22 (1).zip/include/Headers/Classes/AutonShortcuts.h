#include "../Classes/AutonShortcuts.cpp"

extern void lMax(int vel, bool wait);

extern void lMin(int vel, bool wait);

extern void lScore(int vel, bool wait);

extern void lIdle(int vel, bool wait);