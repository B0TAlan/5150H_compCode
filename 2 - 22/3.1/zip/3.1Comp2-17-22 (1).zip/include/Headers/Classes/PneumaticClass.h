#include "../Classes/PneumaticClass.cpp"

extern void setState(bool state);

extern void getState();