#include "../Functions/Pneumatics.cpp"

// Clamp functions
//extern bool auton;
extern bool cOn;

extern void clampOff();
extern void clampOn();

// BackLift f;unctions
extern bool bLD;

extern void bLClose();
extern void bLOpen();
