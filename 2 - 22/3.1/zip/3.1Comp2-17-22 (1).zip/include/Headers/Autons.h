#include "../Autons/Left.cpp"

#include "../Autons/Other.cpp"
#include "../Autons/Skills.cpp"


extern void leftMid();

extern void gyroConfig();