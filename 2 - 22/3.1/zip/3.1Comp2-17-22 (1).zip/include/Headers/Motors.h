#include "../Functions/Motors.cpp"
// Lift functions
extern void setLiftVel(int p);

extern void liftControl();

// Pringle intake functions(p2)
extern void pringleIntake();

// Pringle intake functions(p1)
extern void setPingle();
extern void spinPringle();

