#include "vex.h"
#include "Headers/Classes/PidClass.h"

void rightTest(){
  Drive(24, 1, 0.001, 0.2);
}