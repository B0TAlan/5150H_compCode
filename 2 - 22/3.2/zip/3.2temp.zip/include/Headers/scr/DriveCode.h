#ifndef DRIVECODE_H
#define DRIVECODE_H

extern vex::brakeType driveBrake;

extern void setBrake();

extern void logTank();

#endif