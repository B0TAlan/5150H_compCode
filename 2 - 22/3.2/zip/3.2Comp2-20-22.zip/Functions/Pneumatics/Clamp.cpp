#include "vex.h"

bool cOn = false;

void clampOpen(){
  Clamp.set(true);

}

void clampCloes(){
  Clamp.set(false);

}