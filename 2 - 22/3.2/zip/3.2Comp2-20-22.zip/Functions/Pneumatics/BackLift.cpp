#include "vex.h"
#include "vex.h"

bool bLD = false;

void bLOpen(){
  bL.set(false);

}

void bLClose(){
  bL.set(true);
}