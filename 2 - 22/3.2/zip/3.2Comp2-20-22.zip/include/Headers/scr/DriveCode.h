#ifndef DRIVECODE_H
#define DRIVECODE_H

extern bool rT;

extern void runTemp();

extern vex::brakeType driveBrake;

extern void setBrake();

extern void logTank();

#endif