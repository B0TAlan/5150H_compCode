#ifndef CLAMP_H
#define CLAMP_H

#include "../Functions/Pneumatics/Clamp.cpp"

extern bool cOn;

extern void clampOpen();
extern void clampCloes();

#endif