
#ifndef MASTERAUTON_H
#define MASTERAUTON_H


#include "Headers/Autons/Skills.h"
#include "Headers/Autons/Right.h"
#include "Headers/Autons/Left.h"

#endif