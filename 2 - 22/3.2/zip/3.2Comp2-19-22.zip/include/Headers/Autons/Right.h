#ifndef  RIGHT_H
#define RIGHT_H

#include "../Autons/Right.cpp"

extern void right20();

extern void rightMid();


#endif