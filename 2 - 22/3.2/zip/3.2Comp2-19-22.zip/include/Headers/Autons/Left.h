#ifndef  LEFT_H
#define LEFT_H

#include "../Autons/Left.cpp"

extern void left20();

extern void leftMid();


#endif