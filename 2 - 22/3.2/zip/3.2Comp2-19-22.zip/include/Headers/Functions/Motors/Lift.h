#ifndef  LIFT_H
#define LIFT_H

#include "../Functions/Motors/Lift.cpp"

extern void liftControl();

#endif