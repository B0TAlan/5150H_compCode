#ifndef  PRINGLE_H
#define PRINGLE_H

#include "../Functions/Motors/Pringle.cpp"

extern void pringleIntake();

#endif