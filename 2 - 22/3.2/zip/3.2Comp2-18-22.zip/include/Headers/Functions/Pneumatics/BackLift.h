#ifndef BACKLIFT_H
#define BACKLIFT_H

#include "../Functions/Pneumatics/BackLift.cpp"

extern bool bLD;

extern void bLOpen();
extern void bLCloes();

#endif